import React from 'react'
import Layout from '../components/utils/Layout';
import CreateNft from "../components/pages/CreateNft"

function home() {
  
    return (
        <Layout>
            <CreateNft />
        </Layout>
    )
}



export default home