import React  from 'react'
import Collection from '../components/pages/Collection'
import Layout from '../components/utils/Layout'

const collection = () => {
  return (
      <Layout>
          <Collection />
    </Layout>
  )
}

export default collection
