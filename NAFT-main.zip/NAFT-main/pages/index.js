
import React from 'react'
import Index from "../components/pages/Index"
import Layout from '../components/utils/Layout'
const Home = () => {

  return (
    <Layout>
      <Index />
    </Layout>
  )
}

export default Home